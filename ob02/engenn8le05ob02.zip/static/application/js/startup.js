
            lms_config = new lms_config_obj();
            lms_config.product_type = "sena";
            lms_config.sco_number = 6202;
            lms_config.lang = "eng";
            lms_config.student_id = 1;
            